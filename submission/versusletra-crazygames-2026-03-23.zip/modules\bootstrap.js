export function registerServiceWorker(options = {}) {
    const { disable = false } = options;

    if (!('serviceWorker' in navigator)) return;

    if (disable) {
        navigator.serviceWorker.getRegistrations()
            .then((registrations) => Promise.all(registrations.map((reg) => reg.unregister())))
            .catch((error) => console.warn('Failed to unregister Service Workers:', error));
        return;
    }

    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js')
            .then((reg) => console.log('Service Worker registrado!', reg))
            .catch((err) => console.log('Erro ao registrar SW:', err));
    });
}
